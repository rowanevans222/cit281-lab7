// Custom error class
class CustomError extends Error {
  constructor(message) {
    super(message);
    this.name = "CustomError";
  }
}

// Generic error function
function throwGenericError() {
  throw new Error("Generic error");
}

// Custom error function
function throwCustomError() {
  throw new CustomError("Custom error");
}

// Try/catch/finally with generic error
try {
  console.log("Trying generic error...");
  throwGenericError();
} catch (err) {
  console.error("Caught:", err);
} finally {
  console.log("Finally block for generic error\n");
}

// Try/catch/finally with custom error
try {
  console.log("Trying custom error...");
  throwCustomError();
} catch (err) {
  console.error("Caught:", err);
} finally {
  console.log("Finally block for custom error");
}